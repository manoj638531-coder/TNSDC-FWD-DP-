let html5QrCode;
const qrRegionId = "reader";
const output = document.getElementById("output");

// Start Scanner
document.getElementById("startScan").addEventListener("click", () => {
  if (!html5QrCode) {
    html5QrCode = new Html5Qrcode(qrRegionId);
  }

  html5QrCode.start(
    { facingMode: "environment" }, // use back camera
    {
      fps: 10, // frames per second
      qrbox: { width: 250, height: 250 } // scan area size
    },
    (decodedText) => {
      output.innerText = decodedText;

      // If it's a link, make it clickable
      if (decodedText.startsWith("http")) {
        output.innerHTML = `<a href="${decodedText}" target="_blank">${decodedText}</a>`;
      }
    },
    (errorMessage) => {
      // console.log("Scanning error:", errorMessage);
    }
  ).catch((err) => {
    console.error("Camera start failed:", err);
  });
});

// Stop Scanner
document.getElementById("stopScan").addEventListener("click", () => {
  if (html5QrCode) {
    html5QrCode.stop().then(() => {
      console.log("Camera stopped.");
    }).catch((err) => {
      console.error("Stop failed:", err);
    });
  }
});